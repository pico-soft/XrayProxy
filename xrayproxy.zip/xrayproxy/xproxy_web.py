#!/data/data/com.termux/files/usr/bin/env python3
"""XrayProxy Web — pico-soft — v.1.0-beta"""

import sys, os, json, threading, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

try:
    from flask import Flask, render_template, request, redirect, url_for, jsonify
except ImportError:
    print("pip install flask --break-system-packages"); sys.exit(1)

import xproxy_lib as lib

app = Flask(__name__, template_folder=str(Path(__file__).parent / "templates"))
app.secret_key = "xproxy_local"

_task = {"running": False, "type": "", "progress": [], "done": False}
_lock = threading.Lock()

def tlog(m):
    with _lock: _task["progress"].append(m)

def run_bg(func, name="task"):
    with _lock:
        if _task["running"]: return False
        _task.update({"running": True, "type": name, "progress": [], "done": False})
    def w():
        try: func()
        except Exception as e: tlog(f"Ошибка: {e}")
        finally:
            with _lock: _task.update({"running": False, "done": True})
    threading.Thread(target=w, daemon=True).start(); return True

@app.route("/")
def index():
    running = lib.xray_is_running()
    cur = lib.get_current_server()
    ip = lib.check_external_ip() if running else None
    scope = lib.get_active_scope()
    return render_template("index.html",
        version=lib.VERSION, app_name=lib.APP_NAME,
        is_running=running, current=cur, external_ip=ip,
        servers=lib.sort_servers_by_speed(lib.get_servers_by_scope(scope)),
        alive_servers=lib.sort_servers_by_speed(lib.get_alive_servers(scope)),
        subs=lib.get_subscriptions(),
        active_url=lib.get_active_subscription(),
        active_name=lib.get_subscription_name(lib.get_active_subscription()) if lib.get_active_subscription() else "Все",
        timeout=lib.get_proxy_check_timeout(),
        bg_running=lib.is_background_running(),
        blacklist=lib.get_blacklist(),
        last_test=lib.get_last_test_time(),
        last_update=lib.get_last_update_time(),
        task=_task)

@app.route("/connect/<int:idx>")
def connect(idx):
    scope = lib.get_active_scope()
    servers = lib.sort_servers_by_speed(lib.get_servers_by_scope(scope))
    if 0 <= idx < len(servers):
        if lib.xray_is_running(): lib.xray_stop()
        lib.xray_start_with(servers[idx])
    return redirect("/")

@app.route("/auto_connect")
def auto_connect():
    scope = lib.get_active_scope()
    best = lib.find_fastest_server(scope)
    if best:
        if lib.xray_is_running(): lib.xray_stop()
        lib.xray_start_with(best)
        return redirect("/")
    def do():
        s = lib.get_servers_by_scope(scope)
        if not s: tlog("Нет серверов"); return
        tlog(f"Пинг ({len(s)})..."); alive = lib.run_ping_tests(s, lambda i,t,n,p: tlog(f"[{i}/{t}] {n[:30]} {'OK '+str(p) if p>0 else 'нет'}"))
        if not alive: tlog("Никто не ответил"); return
        tlog(f"Прокси ({len(alive)})..."); wrk = lib.run_proxy_checks(alive, lambda i,t,n,ok: tlog(f"[{i}/{t}] {n[:30]} {'✓' if ok else '✗'}"))
        if not wrk: tlog("Нет рабочих"); return
        tlog(f"Скорость ({len(wrk)})..."); lib.run_speed_tests(wrk, lambda i,t,n,s: tlog(f"[{i}/{t}] {n[:30]} {s}Мб/с" if s>0 else f"[{i}/{t}] {n[:30]} 0"))
        b = lib.find_fastest_server(scope)
        if b:
            if lib.xray_is_running(): lib.xray_stop()
            lib.xray_start_with(b); tlog(f"✓ {b.get('NAME','?')}")
    run_bg(do, "auto"); return redirect("/task")

@app.route("/next_server")
def next_server():
    cur = lib.get_current_server()
    if cur:
        nxt = lib.find_next_server(cur.get("SOURCE", lib.get_active_scope()))
        if nxt:
            if lib.xray_is_running(): lib.xray_stop()
            lib.xray_start_with(nxt)
    return redirect("/")

@app.route("/stop")
def stop(): lib.xray_stop(); return redirect("/")

@app.route("/start")
def start():
    cur = lib.get_current_server()
    if cur: lib.xray_start_with(cur)
    return redirect("/")

@app.route("/run_tests")
def run_tests():
    scope = lib.get_active_scope()
    def do():
        s = lib.get_servers_by_scope(scope)
        if not s: tlog("Нет серверов"); return
        tlog(f"1/3 Пинг ({len(s)})..."); alive = lib.run_ping_tests(s, lambda i,t,n,p: tlog(f"[{i}/{t}] {n[:30]} {'OK '+str(p) if p>0 else 'нет'}"))
        tlog(f"Откликнулись: {len(alive)}")
        if not alive: return
        tlog(f"2/3 Прокси ({len(alive)})..."); wrk = lib.run_proxy_checks(alive, lambda i,t,n,ok: tlog(f"[{i}/{t}] {n[:30]} {'✓' if ok else '✗'}"))
        tlog(f"Рабочих: {len(wrk)}")
        if not wrk: return
        tlog(f"3/3 Скорость ({len(wrk)})..."); lib.run_speed_tests(wrk, lambda i,t,n,s: tlog(f"[{i}/{t}] {n[:30]} {s}Мб/с" if s>0 else f"[{i}/{t}] {n[:30]} 0"))
        tlog("✓ Готово")
    run_bg(do, "test"); return redirect("/task")

@app.route("/task")
def task_page(): return render_template("task.html", version=lib.VERSION, app_name=lib.APP_NAME, task=_task)

@app.route("/task_status")
def task_status():
    with _lock: return jsonify(_task)

@app.route("/add_sub", methods=["POST"])
def add_sub():
    url = request.form.get("url","").strip(); name = request.form.get("name","").strip()
    if url:
        lib.add_subscription(url, name or None)
        def do():
            tlog(f"Загружаю: {url[:50]}...")
            ok, added, skip = lib.update_single_subscription(url, progress_cb=tlog)
            if ok: tlog(f"+{added} серверов")
            else: tlog("Ошибка загрузки")
        run_bg(do, "add_sub"); return redirect("/task")
    return redirect("/")

@app.route("/del_sub/<int:idx>")
def del_sub(idx):
    subs = lib.get_subscriptions()
    if 0<=idx<len(subs): lib.remove_subscription(subs[idx]["url"])
    return redirect("/")

@app.route("/set_active_sub/<int:idx>")
def set_active_sub(idx):
    if idx == -1: lib.set_active_subscription(None)
    else:
        subs = lib.get_subscriptions()
        if 0<=idx<len(subs): lib.set_active_subscription(subs[idx]["url"])
    return redirect("/")

@app.route("/update_subs")
def update_subs():
    scope = lib.get_active_scope()
    def do():
        urls = lib.get_subscription_urls() if scope=="ALL" else [scope]
        for url in urls:
            tlog(f"Обновляю: {lib.get_subscription_name(url)}...")
            ok, added, _ = lib.update_single_subscription(url, progress_cb=tlog)
            if ok: tlog(f"+{added}")
            else: tlog("Ошибка")
    run_bg(do, "update"); return redirect("/task")

@app.route("/set_timeout", methods=["POST"])
def set_timeout():
    try: lib.set_proxy_check_timeout(int(request.form.get("timeout", "2")))
    except: pass
    return redirect("/")

@app.route("/toggle_bg")
def toggle_bg():
    if lib.is_background_running(): lib.stop_background_check()
    else: lib.start_background_check()
    return redirect("/")

@app.route("/add_blacklist", methods=["POST"])
def add_blacklist():
    w = request.form.get("word","").strip()
    if w: lib.add_to_blacklist(w)
    return redirect("/")

@app.route("/del_blacklist/<int:idx>")
def del_blacklist(idx):
    bl = lib.get_blacklist()
    if 0<=idx<len(bl): lib.remove_from_blacklist(bl[idx])
    return redirect("/")

@app.route("/check_speed")
def check_speed():
    r = lib.measure_current_speed(); cur = lib.get_current_server()
    if r and cur:
        mbps, tt = r
        lib.update_server_meta(cur["_file"], {"SPEED_MBPS": mbps, "LAST_TESTED": lib._now_str()})
        return jsonify({"mbps": mbps, "time": round(tt, 2)})
    return jsonify({"mbps": 0, "time": 0})

@app.route("/export_logs")
def export_logs():
    p = lib.export_logs()
    return jsonify({"ok": bool(p), "path": p or ""})

@app.route("/refresh_alive")
def refresh_alive():
    """Возвращает актуальный JSON живых серверов."""
    scope = lib.get_active_scope()
    alive = lib.get_alive_servers(scope)
    data = [{"name": s.get("NAME"), "host": s.get("HOST"), "port": s.get("PORT"),
             "ping": s.get("PING_MS"), "speed": s.get("SPEED_MBPS"),
             "tested": s.get("LAST_TESTED")} for s in lib.sort_servers_by_speed(alive)]
    return jsonify(data)

def main():
    lib.init()
    if not lib.xray_installed():
        print("Устанавливаю xray..."); lib.install_xray(progress_cb=print)
    if lib.needs_migration() and lib.get_subscription_urls():
        print("Мигрирую..."); lib.migrate(progress_cb=print)
    print(f"\n  {lib.APP_NAME} v.{lib.VERSION} — Web\n  http://localhost:8080\n")
    app.run(host="127.0.0.1", port=8080, debug=False)

if __name__ == "__main__":
    main()
