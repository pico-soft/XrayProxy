#!/data/data/com.termux/files/usr/bin/bash
# ============================================
# Установщик XrayProxy 1.0-beta — pico-soft
# https://github.com/pico-soft/XrayProxy
# ============================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; GRAY='\033[0;90m'; NC='\033[0m'

PROJECT_DIR="$HOME/xproxy"
LAUNCHER="$HOME/xproxy.sh"

PROJECT_FILES=("xproxy_lib.py" "xproxy_cli.py" "xproxy_web.py" "xproxy.sh")
TEMPLATE_FILES=("templates/index.html" "templates/task.html")
OPTIONAL_FILES=("blacklist.txt")

DOWNLOAD_DIRS=(
    "$HOME/storage/downloads/Telegram" "$HOME/storage/shared/Download/Telegram"
    "$HOME/storage/downloads" "$HOME/storage/shared/Download"
)

echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}  XrayProxy 1.0-beta installer   ${NC}"
echo -e "${CYAN}  pico-soft                       ${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Хранилище
if [ ! -d "$HOME/storage" ]; then
    echo -e "${YELLOW}Настраиваю доступ к хранилищу...${NC}"
    termux-setup-storage; sleep 3
    [ ! -d "$HOME/storage" ] && echo -e "${RED}Не удалось.${NC}" && exit 1
fi

# Пакеты
echo -e "${CYAN}[1/5] Пакеты...${NC}"
command -v python3 >/dev/null || { echo -e "${YELLOW}  python...${NC}"; pkg install -y python >/dev/null 2>&1; }
command -v curl >/dev/null || { echo -e "${YELLOW}  curl...${NC}"; pkg install -y curl >/dev/null 2>&1; }
command -v unzip >/dev/null || { echo -e "${YELLOW}  unzip...${NC}"; pkg install -y unzip >/dev/null 2>&1; }
python3 -c "import flask" 2>/dev/null || { echo -e "${YELLOW}  flask...${NC}"; pip install flask --break-system-packages -q 2>/dev/null || pip install flask -q 2>/dev/null; }
echo -e "  ${GREEN}✓${NC} Всё установлено"

# Папки
echo -e "${CYAN}[2/5] Папки...${NC}"
mkdir -p "$PROJECT_DIR/servers" "$PROJECT_DIR/templates"
echo -e "  ${GREEN}✓${NC} $PROJECT_DIR"

# Поиск файлов
echo -e "${CYAN}[3/5] Файлы...${NC}"
SOURCE_DIR=""
for dir in "${DOWNLOAD_DIRS[@]}"; do
    for sub in "/xrayproxy" "/zodchy-xproxy" "/XrayProxy" ""; do
        [ -f "$dir$sub/xproxy_lib.py" ] && SOURCE_DIR="$dir$sub" && break 2
    done
done
[ -z "$SOURCE_DIR" ] && echo -e "  ${RED}✗ Не найдены. Скачай файлы и повтори.${NC}" && exit 1
echo -e "  ${GREEN}✓${NC} $SOURCE_DIR"

# Версии и бэкап
echo -e "${CYAN}[4/5] Установка...${NC}"
NEW_V=$(grep -m1 'VERSION = ' "$SOURCE_DIR/xproxy_lib.py" | grep -o '"[^"]*"' | tr -d '"')
OLD_V=""
[ -f "$PROJECT_DIR/xproxy_lib.py" ] && OLD_V=$(grep -m1 'VERSION = ' "$PROJECT_DIR/xproxy_lib.py" | grep -o '"[^"]*"' | tr -d '"')

if [ -n "$OLD_V" ] && [ "$OLD_V" != "$NEW_V" ]; then
    echo -e "  ${YELLOW}Обновление: $OLD_V → $NEW_V${NC}"
    for f in "${PROJECT_FILES[@]}"; do
        [ -f "$PROJECT_DIR/$f" ] && cp "$PROJECT_DIR/$f" "$PROJECT_DIR/${f}.${OLD_V}.bak"
    done
    echo -e "  ${GRAY}Бэкап создан${NC}"
elif [ -n "$OLD_V" ]; then
    echo -e "  ${GRAY}Переустановка $OLD_V${NC}"
else
    echo -e "  ${GREEN}Первая установка $NEW_V${NC}"
fi

for f in "${PROJECT_FILES[@]}"; do
    [ -f "$SOURCE_DIR/$f" ] && cp "$SOURCE_DIR/$f" "$PROJECT_DIR/$f" && echo -e "  ${GREEN}✓${NC} $f"
done
for f in "${TEMPLATE_FILES[@]}"; do
    [ -f "$SOURCE_DIR/$f" ] && cp "$SOURCE_DIR/$f" "$PROJECT_DIR/$f" && echo -e "  ${GREEN}✓${NC} $f"
done
for f in "${OPTIONAL_FILES[@]}"; do
    if [ ! -f "$PROJECT_DIR/$f" ] && [ -f "$SOURCE_DIR/$f" ]; then
        cp "$SOURCE_DIR/$f" "$PROJECT_DIR/$f"; echo -e "  ${GREEN}✓${NC} $f"
    fi
done
chmod +x "$PROJECT_DIR/xproxy.sh" "$PROJECT_DIR/xproxy_cli.py" "$PROJECT_DIR/xproxy_web.py" 2>/dev/null

# Лаунчер
echo -e "${CYAN}[5/5] Лаунчер...${NC}"
cat > "$LAUNCHER" << EOF
#!/data/data/com.termux/files/usr/bin/bash
DIR="$PROJECT_DIR"
case "\${1:-cli}" in
    web) echo "XrayProxy Web → http://localhost:8080"; exec python3 "\$DIR/xproxy_web.py" ;;
    stop) python3 -c "import sys;sys.path.insert(0,'\$DIR');import xproxy_lib as l;l.init();l.xray_stop() if l.xray_is_running() else None;print('OK')" ;;
    *) exec python3 "\$DIR/xproxy_cli.py" "\$@" ;;
esac
EOF
chmod +x "$LAUNCHER"
echo -e "  ${GREEN}✓${NC} ~/xproxy.sh"

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  ✓ XrayProxy $NEW_V установлен!  ${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "  CLI:  ${BLUE}bash ~/xproxy.sh${NC}"
echo -e "  Web:  ${BLUE}bash ~/xproxy.sh web${NC}"
echo -e "  Stop: ${BLUE}bash ~/xproxy.sh stop${NC}"
echo ""
