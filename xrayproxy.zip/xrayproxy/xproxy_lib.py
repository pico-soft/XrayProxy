"""
XrayProxy — ядро логики
pico-soft | https://github.com/pico-soft/XrayProxy
Версия: 1.0-beta

SOCKS5/HTTP прокси без VPN-интерфейса для Android (Termux).
Невидим для приложений, проверяющих наличие VPN.
"""

import os
import sys
import json
import time
import socket
import base64
import signal
import shutil
import logging
import subprocess
import urllib.parse
import urllib.request
from pathlib import Path
from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler
from typing import Optional, List, Dict, Any, Tuple

VERSION = "1.0-beta"
APP_NAME = "XrayProxy"
APP_AUTHOR = "pico-soft"
APP_REPO = "https://github.com/pico-soft/XrayProxy"

# --- Пути и константы ---

HOME = Path(os.environ.get("HOME", str(Path.home())))
XRAY_DIR = HOME / "xproxy"
XRAY_BIN = XRAY_DIR / "xray"
CONFIG_FILE = XRAY_DIR / "config.json"
TEST_CONFIG = XRAY_DIR / "test_config.json"
FETCH_CONFIG = XRAY_DIR / "fetch_config.json"
SUBS_FILE = XRAY_DIR / "subscriptions.json"
BLACKLIST_FILE = XRAY_DIR / "blacklist.txt"
SETTINGS_FILE = XRAY_DIR / "settings.json"
SERVERS_DIR = XRAY_DIR / "servers"
PID_FILE = XRAY_DIR / "xray.pid"
TEST_PID_FILE = XRAY_DIR / "xray_test.pid"
FETCH_PID_FILE = XRAY_DIR / "xray_fetch.pid"
BG_PID_FILE = XRAY_DIR / "bg_check.pid"
LOG_FILE = XRAY_DIR / "xray.log"
APP_LOG_FILE = XRAY_DIR / "xrayproxy.log"

APP_LOG_MAX_BYTES = 200_000
APP_LOG_BACKUP_COUNT = 1

SOCKS_PORT = 10828
HTTP_PORT = 10829
TEST_SOCKS_PORT = 10830
FETCH_SOCKS_PORT = 10831

DEFAULT_PROXY_CHECK_TIMEOUT = 2
BG_CHECK_INTERVAL = 3600

DEFAULT_BLACKLIST = [
    "москва", "россия", "санкт-петербург", "беларусь", "минск", "крым",
    "moscow", "russia", "st. petersburg", "belarus", "minsk", "crimea",
]

XRAY_DOWNLOAD_URL = (
    "https://github.com/XTLS/Xray-core/releases/latest/download/"
    "Xray-android-arm64-v8a.zip"
)

SPEED_TEST_URL = "https://speed.cloudflare.com/__down?bytes=5000000"
IP_CHECK_URL = "https://api.ipify.org"
USER_AGENT = "v2rayNG/1.8.0"


# --- Логгирование ---

_logger: Optional[logging.Logger] = None

def _setup_logger() -> logging.Logger:
    global _logger
    if _logger is not None:
        return _logger
    XRAY_DIR.mkdir(exist_ok=True)
    _logger = logging.getLogger("xrayproxy")
    _logger.setLevel(logging.DEBUG)
    _logger.handlers.clear()
    handler = RotatingFileHandler(
        str(APP_LOG_FILE), maxBytes=APP_LOG_MAX_BYTES,
        backupCount=APP_LOG_BACKUP_COUNT, encoding="utf-8")
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
    _logger.addHandler(handler)
    return _logger

def log(msg: str, level: str = "info") -> None:
    logger = _setup_logger()
    logger.log(getattr(logging, level.upper(), logging.INFO), msg)

def log_action(action: str, details: str = "") -> None:
    msg = f"ACTION: {action}"
    if details:
        msg += f" | {details}"
    log(msg)

def get_log_contents() -> str:
    result = ""
    backup = Path(str(APP_LOG_FILE) + ".1")
    if backup.exists():
        try: result += backup.read_text(encoding="utf-8", errors="replace")
        except: pass
    if APP_LOG_FILE.exists():
        try: result += APP_LOG_FILE.read_text(encoding="utf-8", errors="replace")
        except: pass
    return result


# --- Инициализация ---

def init() -> None:
    XRAY_DIR.mkdir(exist_ok=True)
    SERVERS_DIR.mkdir(exist_ok=True)

    if not BLACKLIST_FILE.exists():
        BLACKLIST_FILE.write_text("\n".join(DEFAULT_BLACKLIST) + "\n")

    # Миграция со старого subscriptions.txt
    old_subs = XRAY_DIR / "subscriptions.txt"
    if old_subs.exists() and not SUBS_FILE.exists():
        _migrate_subs_txt(old_subs)

    if not SUBS_FILE.exists():
        SUBS_FILE.write_text("[]")

    if not SETTINGS_FILE.exists():
        save_settings({
            "proxy_check_timeout": DEFAULT_PROXY_CHECK_TIMEOUT,
            "active_subscription": None,
            "last_test_time": None,
            "last_update_time": None,
        })

    log(f"{APP_NAME} v.{VERSION} started")

def _migrate_subs_txt(old_file: Path):
    subs = []
    for line in old_file.read_text().splitlines():
        url = line.strip()
        if url:
            subs.append({"url": url, "name": _name_from_url(url)})
    SUBS_FILE.write_text(json.dumps(subs, indent=2, ensure_ascii=False))
    old_file.rename(str(old_file) + ".migrated")
    log("Migrated subscriptions.txt -> subscriptions.json")

def _name_from_url(url: str) -> str:
    try:
        parsed = urllib.parse.urlparse(url)
        host = parsed.hostname or ""
        path = parsed.path.strip("/")
        if path:
            short_path = path.split("/")[-1][:12]
            return f"{host}/{short_path}"
        return host
    except:
        return url[:30]

def xray_installed() -> bool:
    return XRAY_BIN.exists() and os.access(XRAY_BIN, os.X_OK)

def install_xray(progress_cb=None) -> bool:
    log_action("install_xray")
    def msg(m):
        log(m)
        if progress_cb: progress_cb(m)
    msg("Скачиваю xray-core...")
    zip_path = XRAY_DIR / "xray.zip"
    try:
        with urllib.request.urlopen(XRAY_DOWNLOAD_URL, timeout=60) as resp:
            zip_path.write_bytes(resp.read())
    except Exception as e:
        msg(f"Ошибка: {e}"); return False
    msg("Распаковываю...")
    try:
        import zipfile
        with zipfile.ZipFile(zip_path) as z: z.extractall(XRAY_DIR)
        XRAY_BIN.chmod(0o755); zip_path.unlink()
        msg("Готово."); return True
    except Exception as e:
        msg(f"Ошибка: {e}"); return False


# --- Настройки ---

def load_settings() -> Dict[str, Any]:
    try: return json.loads(SETTINGS_FILE.read_text())
    except: return {"proxy_check_timeout": DEFAULT_PROXY_CHECK_TIMEOUT, "active_subscription": None, "last_test_time": None, "last_update_time": None}

def save_settings(s: Dict[str, Any]):
    SETTINGS_FILE.write_text(json.dumps(s, indent=2, ensure_ascii=False))

def get_proxy_check_timeout() -> int:
    return load_settings().get("proxy_check_timeout", DEFAULT_PROXY_CHECK_TIMEOUT)

def set_proxy_check_timeout(sec: int):
    s = load_settings(); s["proxy_check_timeout"] = max(1, sec); save_settings(s)
    log_action("set_timeout", str(sec))

def get_active_subscription() -> Optional[str]:
    return load_settings().get("active_subscription")

def set_active_subscription(url: Optional[str]):
    s = load_settings(); s["active_subscription"] = url; save_settings(s)
    if url: log_action("set_active_sub", get_subscription_name(url))

def get_last_test_time() -> Optional[str]:
    return load_settings().get("last_test_time")

def set_last_test_time():
    s = load_settings(); s["last_test_time"] = datetime.now().strftime("%Y-%m-%d %H:%M"); save_settings(s)

def get_last_update_time() -> Optional[str]:
    return load_settings().get("last_update_time")

def set_last_update_time():
    s = load_settings(); s["last_update_time"] = datetime.now().strftime("%Y-%m-%d %H:%M"); save_settings(s)

def get_active_scope() -> str:
    active = get_active_subscription()
    if active and active in get_subscription_urls(): return active
    return "ALL"


# --- Подписки (JSON) ---

def get_subscriptions() -> List[Dict[str, str]]:
    try:
        data = json.loads(SUBS_FILE.read_text())
        return data if isinstance(data, list) else []
    except: return []

def get_subscription_urls() -> List[str]:
    return [s["url"] for s in get_subscriptions() if s.get("url")]

def get_subscription_name(url: str) -> str:
    for s in get_subscriptions():
        if s.get("url") == url: return s.get("name", _name_from_url(url))
    return _name_from_url(url)

def add_subscription(url: str, name: str = None):
    url = url.strip()
    if not url: return
    if name is None: name = _name_from_url(url)
    subs = get_subscriptions()
    if any(s["url"] == url for s in subs): return
    subs.append({"url": url, "name": name})
    SUBS_FILE.write_text(json.dumps(subs, indent=2, ensure_ascii=False))
    log_action("add_sub", f"{name}")
    if len(subs) == 1: set_active_subscription(url)

def remove_subscription(url: str):
    log_action("remove_sub", get_subscription_name(url))
    subs = [s for s in get_subscriptions() if s.get("url") != url]
    SUBS_FILE.write_text(json.dumps(subs, indent=2, ensure_ascii=False))
    for meta in list_server_files():
        if meta.get("SOURCE") == url: Path(meta["_file"]).unlink(missing_ok=True)
    if get_active_subscription() == url:
        remaining = get_subscription_urls()
        set_active_subscription(remaining[0] if remaining else None)

def count_servers_in_sub(url: str) -> int:
    return sum(1 for m in list_server_files() if m.get("SOURCE") == url)


# --- Стоп-лист ---

def get_blacklist() -> List[str]:
    if not BLACKLIST_FILE.exists(): return []
    return [l.strip().lower() for l in BLACKLIST_FILE.read_text().splitlines() if l.strip()]

def add_to_blacklist(word: str) -> bool:
    word = word.strip().lower()
    if not word: return False
    current = get_blacklist()
    if word in current: return False
    with BLACKLIST_FILE.open("a") as f: f.write(word + "\n")
    log_action("blacklist_add", word); return True

def remove_from_blacklist(word: str) -> bool:
    current = get_blacklist()
    if word not in current: return False
    current.remove(word)
    BLACKLIST_FILE.write_text("\n".join(current) + ("\n" if current else ""))
    log_action("blacklist_remove", word); return True

def check_blacklisted(name: str) -> bool:
    return any(kw in name.lower() for kw in get_blacklist())


# --- Парсинг VLESS ---

def parse_vless(uri: str) -> Optional[Dict[str, Any]]:
    if not uri.startswith("vless://"): return None
    try:
        parsed = urllib.parse.urlparse(uri)
        params = urllib.parse.parse_qs(parsed.query)
        def get(k, d=""): v = params.get(k, [d]); return v[0] if v else d
        return {
            "NAME": urllib.parse.unquote(parsed.fragment) or "",
            "HOST": parsed.hostname or "", "PORT": parsed.port or 443,
            "UUID": parsed.username or "",
            "SECURITY": get("security", "none"), "SNI": get("sni"),
            "FP": get("fp", "chrome"), "PBK": get("pbk"), "SID": get("sid"),
            "FLOW": get("flow"), "TYPE": get("type", "tcp"),
            "SERVICENAME": get("serviceName"), "PATH": get("path"),
            "HOST_HEADER": get("host"), "HEADERTYPE": get("headerType"),
            "ALPN": get("alpn"),
        }
    except: return None

def parse_subscription_content(content: str, source_url: str) -> Tuple[int, int]:
    try:
        padded = content + "=" * (-len(content) % 4)
        decoded = base64.b64decode(padded).decode("utf-8", errors="ignore")
        if "vless://" in decoded: content = decoded
    except: pass

    for meta in list_server_files():
        if meta.get("SOURCE") == source_url: Path(meta["_file"]).unlink(missing_ok=True)

    existing = [int(f.stem) for f in SERVERS_DIR.glob("*.meta") if f.stem.isdigit()]
    idx = max(existing) + 1 if existing else 1
    added = skipped = 0

    for line in content.splitlines():
        line = line.strip()
        if not line.startswith("vless://"): continue
        meta = parse_vless(line)
        if not meta: continue
        if check_blacklisted(meta["NAME"]): skipped += 1; continue
        if not meta["NAME"]: meta["NAME"] = f"Server {idx}"
        meta.update({"PING_MS": -1, "SPEED_MBPS": -1, "SOURCE": source_url, "LAST_TESTED": None})
        (SERVERS_DIR / f"{idx}.meta").write_text(json.dumps(meta, ensure_ascii=False))
        idx += 1; added += 1

    log(f"parse: src={source_url[:50]} added={added} skip={skipped}")
    return added, skipped


# --- Серверы ---

def list_server_files() -> List[Dict[str, Any]]:
    result = []
    for f in sorted(SERVERS_DIR.glob("*.meta")):
        try:
            data = json.loads(f.read_text()); data["_file"] = str(f)
            result.append(data)
        except: continue
    return result

def get_servers_by_scope(scope: str) -> List[Dict[str, Any]]:
    all_s = list_server_files()
    return all_s if scope == "ALL" else [s for s in all_s if s.get("SOURCE") == scope]

def get_alive_servers(scope: str = "ALL") -> List[Dict[str, Any]]:
    """Только живые серверы с положительным пингом и скоростью."""
    return [s for s in get_servers_by_scope(scope) if s.get("PING_MS", -1) > 0 and s.get("SPEED_MBPS", -1) > 0]

def update_server_meta(meta_file: str, updates: Dict[str, Any]):
    path = Path(meta_file)
    try: data = json.loads(path.read_text())
    except: return
    data.update(updates); data.pop("_file", None)
    path.write_text(json.dumps(data, ensure_ascii=False))

def sort_servers_by_speed(servers: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    def key(x):
        speed, ping = x.get("SPEED_MBPS", -1), x.get("PING_MS", -1)
        if speed > 0: return (0, -speed)
        elif ping > 0: return (1, ping)
        return (2, 0)
    return sorted(servers, key=key)


# --- Генерация конфига xray ---

def generate_config(meta: Dict[str, Any], socks_port: int, output: Path):
    user = {"id": meta["UUID"], "encryption": "none", "level": 0}
    if meta.get("FLOW"): user["flow"] = meta["FLOW"]

    stream = {"network": meta.get("TYPE") or "tcp"}
    sec = meta.get("SECURITY") or "none"
    if sec != "none": stream["security"] = sec

    if sec == "reality":
        stream["realitySettings"] = {"serverName": meta.get("SNI", ""), "fingerprint": meta.get("FP") or "chrome", "publicKey": meta.get("PBK", ""), "shortId": meta.get("SID", "")}
    elif sec == "tls":
        tls = {"serverName": meta.get("SNI", ""), "fingerprint": meta.get("FP") or "chrome"}
        if meta.get("ALPN"): tls["alpn"] = meta["ALPN"].split(",")
        stream["tlsSettings"] = tls

    nt = meta.get("TYPE") or "tcp"
    if nt == "grpc": stream["grpcSettings"] = {"serviceName": meta.get("SERVICENAME", ""), "multiMode": True}
    elif nt == "ws":
        h = {}; hh = meta.get("HOST_HEADER") or meta.get("SNI", "")
        if hh: h["Host"] = hh
        stream["wsSettings"] = {"path": meta.get("PATH", "/"), "headers": h}
    elif nt == "tcp" and meta.get("HEADERTYPE") == "http":
        stream["tcpSettings"] = {"header": {"type": "http"}}

    config = {
        "log": {"loglevel": "warning"},
        "inbounds": [{"listen": "127.0.0.1", "port": socks_port, "protocol": "socks", "settings": {"udp": True}, "tag": "socks-in"}],
        "outbounds": [
            {"protocol": "vless", "settings": {"vnext": [{"address": meta["HOST"], "port": int(meta["PORT"]), "users": [user]}]}, "streamSettings": stream, "tag": "proxy"},
            {"protocol": "freedom", "tag": "direct"}
        ],
    }
    output.write_text(json.dumps(config, indent=2, ensure_ascii=False))


# --- Управление xray ---

def _is_pid_alive(pf: Path) -> bool:
    if not pf.exists(): return False
    try: pid = int(pf.read_text().strip()); os.kill(pid, 0); return True
    except: return False

def _kill_pid(pf: Path):
    if pf.exists():
        try: os.kill(int(pf.read_text().strip()), signal.SIGTERM)
        except: pass
        pf.unlink(missing_ok=True)

def _start_xray(config: Path, pid_file: Path, log_path: Path) -> bool:
    _kill_pid(pid_file)
    test = subprocess.run([str(XRAY_BIN), "-test", "-config", str(config)], capture_output=True, text=True, timeout=10)
    if test.returncode != 0:
        log_path.write_text("Config error:\n" + test.stderr + test.stdout); return False
    lf = open(log_path, "w")
    proc = subprocess.Popen([str(XRAY_BIN), "run", "-config", str(config)], stdout=lf, stderr=subprocess.STDOUT, start_new_session=True)
    pid_file.write_text(str(proc.pid)); time.sleep(1.5)
    return _is_pid_alive(pid_file)

def xray_is_running() -> bool: return _is_pid_alive(PID_FILE)
def xray_stop(): log_action("xray_stop"); _kill_pid(PID_FILE)

def xray_start_with(meta: Dict[str, Any]) -> bool:
    name = meta.get("NAME", "?")
    log_action("xray_start", f"{name} @ {meta.get('HOST')}:{meta.get('PORT')}")
    generate_config(meta, SOCKS_PORT, CONFIG_FILE)
    ok = _start_xray(CONFIG_FILE, PID_FILE, LOG_FILE)
    log(f"xray {'OK' if ok else 'FAIL'}: {name}", level="info" if ok else "error")
    return ok

def get_current_server() -> Optional[Dict[str, Any]]:
    if not CONFIG_FILE.exists(): return None
    try:
        c = json.loads(CONFIG_FILE.read_text())
        v = c["outbounds"][0]["settings"]["vnext"][0]
        host, port = v["address"], v["port"]
    except: return None
    for m in list_server_files():
        if m.get("HOST") == host and int(m.get("PORT", 0)) == int(port): return m
    return None


# --- Тестирование ---

def test_ping(host: str, port: int, timeout: float = 3.0) -> int:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM); s.settimeout(timeout)
        t = time.time(); s.connect((host, port)); ms = int((time.time() - t) * 1000); s.close(); return ms
    except: return -1

def quick_proxy_check(meta: Dict[str, Any], timeout: int = None) -> bool:
    if timeout is None: timeout = get_proxy_check_timeout()
    generate_config(meta, TEST_SOCKS_PORT, TEST_CONFIG)
    if not _start_xray(TEST_CONFIG, TEST_PID_FILE, XRAY_DIR / "xray_test.log"): return False
    try:
        r = subprocess.run(["curl", "-sx", f"socks5h://127.0.0.1:{TEST_SOCKS_PORT}", "--max-time", str(timeout), IP_CHECK_URL], capture_output=True, text=True, timeout=timeout + 5)
        return bool(r.stdout.strip())
    except: return False
    finally: _kill_pid(TEST_PID_FILE)

def test_speed_via_server(meta: Dict[str, Any], timeout: int = 15) -> float:
    generate_config(meta, TEST_SOCKS_PORT, TEST_CONFIG)
    if not _start_xray(TEST_CONFIG, TEST_PID_FILE, XRAY_DIR / "xray_test.log"): return 0.0
    try:
        r = subprocess.run(["curl", "-sx", f"socks5h://127.0.0.1:{TEST_SOCKS_PORT}", "--max-time", str(timeout), "-w", "%{speed_download}", "-o", "/dev/null", SPEED_TEST_URL], capture_output=True, text=True, timeout=timeout + 5)
        return round(float(r.stdout.strip() or 0) * 8 / 1_000_000, 2)
    except: return 0.0
    finally: _kill_pid(TEST_PID_FILE)

def measure_current_speed(timeout: int = 15) -> Optional[Tuple[float, float]]:
    if not xray_is_running(): return None
    try:
        r = subprocess.run(["curl", "-sx", f"socks5h://127.0.0.1:{SOCKS_PORT}", "--max-time", str(timeout), "-w", "%{speed_download}|%{time_total}", "-o", "/dev/null", SPEED_TEST_URL], capture_output=True, text=True, timeout=timeout + 5)
        parts = r.stdout.strip().split("|")
        if len(parts) != 2: return None
        mbps = round(float(parts[0] or 0) * 8 / 1_000_000, 2)
        return (mbps, float(parts[1])) if mbps > 0 else None
    except: return None

def check_external_ip() -> Optional[str]:
    if not xray_is_running(): return None
    try:
        r = subprocess.run(["curl", "-sx", f"socks5h://127.0.0.1:{SOCKS_PORT}", "--max-time", "10", IP_CHECK_URL], capture_output=True, text=True, timeout=15)
        return r.stdout.strip() or None
    except: return None

def _now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")

def run_ping_tests(servers, progress_cb=None) -> list:
    log_action("ping_tests", f"n={len(servers)}")
    alive = []
    for i, m in enumerate(servers, 1):
        ping = test_ping(m["HOST"], m["PORT"])
        upd = {"PING_MS": ping, "LAST_TESTED": _now_str()}
        if ping < 0: upd["SPEED_MBPS"] = -1
        update_server_meta(m["_file"], upd); m["PING_MS"] = ping
        log(f"ping {m.get('NAME','')} -> {ping}", level="debug")
        if progress_cb: progress_cb(i, len(servers), m.get("NAME", ""), ping)
        if ping > 0: alive.append(m)
    log(f"ping done: {len(alive)}/{len(servers)}")
    return alive

def run_proxy_checks(servers, progress_cb=None) -> list:
    log_action("proxy_checks", f"n={len(servers)}")
    working = []
    for i, m in enumerate(servers, 1):
        ok = quick_proxy_check(m)
        log(f"proxy {m.get('NAME','')} -> {'OK' if ok else 'FAIL'}", level="debug")
        if progress_cb: progress_cb(i, len(servers), m.get("NAME", ""), ok)
        if ok: working.append(m)
        else: update_server_meta(m["_file"], {"SPEED_MBPS": 0, "LAST_TESTED": _now_str()}); m["SPEED_MBPS"] = 0
    log(f"proxy done: {len(working)}/{len(servers)}")
    return working

def run_speed_tests(servers, progress_cb=None):
    log_action("speed_tests", f"n={len(servers)}")
    for i, m in enumerate(servers, 1):
        speed = test_speed_via_server(m)
        update_server_meta(m["_file"], {"SPEED_MBPS": speed, "LAST_TESTED": _now_str()}); m["SPEED_MBPS"] = speed
        log(f"speed {m.get('NAME','')} -> {speed}", level="debug")
        if progress_cb: progress_cb(i, len(servers), m.get("NAME", ""), speed)
    set_last_test_time()
    log(f"speed done: {len(servers)} tested")


# --- Fetch подписок ---

def fetch_direct(url: str, timeout: int = 10) -> Optional[str]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as r: return r.read().decode("utf-8", errors="ignore")
    except: return None

def fetch_via_proxy(url: str, via: Dict[str, Any], timeout: int = 20) -> Optional[str]:
    generate_config(via, FETCH_SOCKS_PORT, FETCH_CONFIG)
    if not _start_xray(FETCH_CONFIG, FETCH_PID_FILE, XRAY_DIR / "xray_fetch.log"): return None
    try:
        r = subprocess.run(["curl", "-fsSL", "-x", f"socks5h://127.0.0.1:{FETCH_SOCKS_PORT}", "-A", USER_AGENT, "--max-time", str(timeout), url], capture_output=True, text=True, timeout=timeout + 5)
        return r.stdout if r.returncode == 0 and r.stdout else None
    except: return None
    finally: _kill_pid(FETCH_PID_FILE)

def fetch_subscription(url: str, exclude_source: Optional[str] = None, progress_cb=None) -> Optional[str]:
    log_action("fetch", url[:60])
    def msg(m):
        log(m)
        if progress_cb: progress_cb(m)

    msg("Пробую напрямую...")
    content = fetch_direct(url)
    if content: msg("Загружено напрямую"); return content

    msg("Прямой доступ не удался, ищу прокси...")
    candidates = sort_servers_by_speed([m for m in list_server_files() if m.get("SOURCE") != exclude_source])[:10]
    if not candidates: msg("Нет серверов для туннеля"); return None

    for m in candidates:
        msg(f"Через: {m.get('NAME', '?')}")
        content = fetch_via_proxy(url, m)
        if content: msg(f"OK через {m.get('NAME', '?')}"); return content

    msg("Все варианты исчерпаны"); return None

def update_single_subscription(url: str, progress_cb=None) -> Tuple[bool, int, int]:
    content = fetch_subscription(url, exclude_source=url, progress_cb=progress_cb)
    if not content: return False, 0, 0
    added, skipped = parse_subscription_content(content, url)
    set_last_update_time()
    return True, added, skipped


# --- Авто/переключение ---

def find_fastest_server(scope: str = None) -> Optional[Dict[str, Any]]:
    if scope is None: scope = get_active_scope()
    tested = [s for s in get_servers_by_scope(scope) if s.get("SPEED_MBPS", 0) > 0]
    return max(tested, key=lambda s: s["SPEED_MBPS"]) if tested else None

def find_next_server(scope: str = "ALL") -> Optional[Dict[str, Any]]:
    tested = sorted([s for s in get_servers_by_scope(scope) if s.get("SPEED_MBPS", 0) > 0], key=lambda s: -s["SPEED_MBPS"])
    if not tested: return None
    current = get_current_server()
    if not current: return tested[0]
    ch, cp = current.get("HOST"), current.get("PORT")
    idx = next((i for i, s in enumerate(tested) if s.get("HOST") == ch and int(s.get("PORT", 0)) == int(cp)), -1)
    return tested[(idx + 1) % len(tested)] if idx >= 0 else tested[0]


# --- Миграция ---

def needs_migration() -> bool:
    for m in list_server_files():
        if not m.get("SOURCE"): return True
    return False

def migrate(progress_cb=None):
    def msg(m):
        log(m)
        if progress_cb: progress_cb(m)
    msg("Миграция...")
    for f in SERVERS_DIR.glob("*.meta"): f.unlink()
    for url in get_subscription_urls():
        msg(f"Обновляю: {url[:50]}...")
        update_single_subscription(url, progress_cb=msg)
    msg("Готово.")


# --- Экспорт логов ---

def export_logs(output_dir: Optional[Path] = None) -> Optional[str]:
    import zipfile
    if output_dir is None:
        for c in [HOME / "storage" / "downloads", HOME / "storage" / "shared" / "Download"]:
            if c.exists(): output_dir = c; break
        if output_dir is None: output_dir = XRAY_DIR

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    zp = output_dir / f"xrayproxy_logs_{ts}.zip"

    files = {"xrayproxy.log": APP_LOG_FILE, "xrayproxy.log.1": Path(str(APP_LOG_FILE) + ".1"),
             "xray.log": LOG_FILE, "xray_test.log": XRAY_DIR / "xray_test.log",
             "config.json": CONFIG_FILE, "subscriptions.json": SUBS_FILE, "blacklist.txt": BLACKLIST_FILE}
    try:
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            info = [f"{APP_NAME} v.{VERSION}", f"Export: {datetime.now().isoformat()}",
                    f"Servers: {len(list_server_files())}", f"Alive: {len(get_alive_servers())}",
                    f"Running: {xray_is_running()}"]
            cur = get_current_server()
            if cur: info.append(f"Current: {cur.get('NAME','?')} @ {cur.get('HOST')}")
            z.writestr("system_info.txt", "\n".join(info))
            for n, p in files.items():
                if p.exists(): z.write(p, n)
            # Только живые серверы
            summary = [{"name": s.get("NAME"), "host": s.get("HOST"), "port": s.get("PORT"),
                        "ping_ms": s.get("PING_MS"), "speed_mbps": s.get("SPEED_MBPS"),
                        "last_tested": s.get("LAST_TESTED"), "source": s.get("SOURCE", "")[:60]}
                       for s in sort_servers_by_speed(get_alive_servers())]
            z.writestr("alive_servers.json", json.dumps(summary, indent=2, ensure_ascii=False))
        log_action("export", str(zp)); return str(zp)
    except Exception as e:
        log(f"export error: {e}", level="error"); return None


# --- Фоновая проверка ---

def run_background_check():
    import signal as sig
    sig.signal(sig.SIGTERM, lambda *_: (BG_PID_FILE.unlink(missing_ok=True), sys.exit(0)))
    BG_PID_FILE.write_text(str(os.getpid()))
    log("BG check started")
    while True:
        try:
            servers = list_server_files()
            if servers:
                log(f"BG: {len(servers)} servers")
                alive = run_ping_tests(servers)
                working = run_proxy_checks(alive)
                if working: run_speed_tests(working)
                log(f"BG done: {len(working)}/{len(servers)}")
        except Exception as e:
            log(f"BG error: {e}", level="error")
        time.sleep(BG_CHECK_INTERVAL)

def start_background_check() -> bool:
    if is_background_running(): return True
    proc = subprocess.Popen(
        [sys.executable, "-c",
         f"import sys; sys.path.insert(0, '{XRAY_DIR}'); import xproxy_lib; xproxy_lib.init(); xproxy_lib.run_background_check()"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    BG_PID_FILE.write_text(str(proc.pid))
    log_action("bg_start", f"pid={proc.pid}"); return True

def stop_background_check():
    _kill_pid(BG_PID_FILE); log_action("bg_stop")

def is_background_running() -> bool:
    return _is_pid_alive(BG_PID_FILE)
